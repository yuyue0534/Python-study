import argparse
import os
import sqlite3
from pathlib import Path

from .app import TaskFlow
from .storage import Store


def main():
    parser = argparse.ArgumentParser(description="TaskFlow 全屏终端任务管理器")
    default_db = Path(os.environ.get("TASKFLOW_DB", str(Path.home() / ".taskflow" / "taskflow.db")))
    parser.add_argument("--db", type=Path, default=default_db, help="SQLite 数据库路径")
    parser.add_argument("--demo", action="store_true", help="空数据库载入示例；非空时保留现有数据")
    args = parser.parse_args()
    store = None
    try:
        store = Store(args.db)
        if args.demo and not store.list_tasks():
            store.seed()
        TaskFlow(store).run()
    except (OSError, sqlite3.Error) as error:
        parser.exit(1, f"TaskFlow 无法读写数据：{error}\n请检查 --db 路径和权限。\n")
    finally:
        if store:
            store.close()


if __name__ == "__main__":
    main()
