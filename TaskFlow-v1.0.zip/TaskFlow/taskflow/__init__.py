"""TaskFlow — local-first terminal task manager."""
__version__ = "1.0.0"
