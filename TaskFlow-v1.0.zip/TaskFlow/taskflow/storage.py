"""SQLite persistence and validation. No dependency on the UI."""
from __future__ import annotations

import json
import math
import re
import sqlite3
from datetime import date, datetime, timedelta
from pathlib import Path

STATUSES = {"todo": "待办", "doing": "进行中", "done": "已完成"}
PRIORITIES = {"low": "低", "normal": "中", "high": "高"}
DEFAULTS = {"theme": "textual-dark", "default_priority": "normal", "confirm_exit": True}


class ValidationError(ValueError):
    def __init__(self, errors: dict[str, str]):
        self.errors = errors
        super().__init__("；".join(errors.values()))


def validate_task(data: dict) -> dict:
    """Validate all fields; dates in the past are allowed for overdue tasks."""
    result = {key: str(data.get(key, "")).strip() for key in
              ("title", "description", "project", "tags", "due")}
    errors = {}
    for field, label, maximum in (("title", "标题", 100), ("description", "描述", 2000),
                                   ("project", "项目", 40), ("tags", "标签", 200)):
        if len(result[field]) > maximum:
            errors[field] = f"{label}最多 {maximum} 个字符"
    if not result["title"]:
        errors["title"] = "标题不能为空"
    due = result["due"]
    if due:
        try:
            if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", due):
                raise ValueError
            date.fromisoformat(due)
        except ValueError:
            errors["due"] = "截止日期须为有效的 YYYY-MM-DD，例如 2026-12-31"
    for field, choices in (("status", STATUSES), ("priority", PRIORITIES)):
        result[field] = data.get(field)
        if result[field] not in choices:
            errors[field] = "请选择有效的状态或优先级"
    try:
        result["estimate"] = float(data.get("estimate") or 0)
        if not math.isfinite(result["estimate"]) or not 0 <= result["estimate"] <= 10000:
            raise ValueError
    except (ValueError, TypeError):
        errors["estimate"] = "预计工时须为 0–10000 的有限数字"
    tags = list(dict.fromkeys(t.strip() for t in result["tags"].replace("，", ",").split(",") if t.strip()))
    if len(tags) > 8 or any(len(t) > 20 for t in tags):
        errors["tags"] = "最多 8 个标签，每个最多 20 字，使用逗号分隔"
    result["tags"] = ", ".join(tags)
    if errors:
        raise ValidationError(errors)
    return result


class Store:
    def __init__(self, path: Path | str):
        self.path = Path(path).expanduser().resolve()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(self.path, timeout=5)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.executescript("""
            CREATE TABLE IF NOT EXISTS tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL CHECK(length(trim(title)) BETWEEN 1 AND 100),
                description TEXT NOT NULL DEFAULT '', project TEXT NOT NULL DEFAULT '',
                tags TEXT NOT NULL DEFAULT '', due TEXT NOT NULL DEFAULT '',
                status TEXT NOT NULL CHECK(status IN ('todo','doing','done')),
                priority TEXT NOT NULL CHECK(priority IN ('low','normal','high')),
                estimate REAL NOT NULL CHECK(estimate >= 0 AND estimate <= 10000),
                created_at TEXT NOT NULL, updated_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
            CREATE INDEX IF NOT EXISTS ix_tasks_status_due ON tasks(status, due);
        """)

    def close(self):
        self.conn.close()

    def list_tasks(self, search="", status="all", priority="all", sort="due"):
        rows = [dict(r) for r in self.conn.execute("SELECT * FROM tasks")]
        term = search.strip().casefold()
        rows = [r for r in rows if (status == "all" or r["status"] == status)
                and (priority == "all" or r["priority"] == priority)
                and (not term or term in " ".join(r[k] for k in
                     ("title", "description", "project", "tags")).casefold())]
        if sort == "priority":
            rows.sort(key=lambda r: ({"high": 0, "normal": 1, "low": 2}[r["priority"]], -r["id"]))
        elif sort == "newest":
            rows.sort(key=lambda r: r["id"], reverse=True)
        else:
            rows.sort(key=lambda r: (r["status"] == "done", r["due"] or "9999-12-31", -r["id"]))
        return rows

    def get(self, task_id):
        row = self.conn.execute("SELECT * FROM tasks WHERE id=?", (task_id,)).fetchone()
        return dict(row) if row else None

    def save(self, data: dict, task_id: int | None = None):
        clean = validate_task(data)
        now = datetime.now().isoformat(timespec="seconds")
        with self.conn:
            if task_id is None:
                cur = self.conn.execute("""INSERT INTO tasks
                    (title,description,project,tags,due,status,priority,estimate,created_at,updated_at)
                    VALUES (:title,:description,:project,:tags,:due,:status,:priority,:estimate,:now,:now)
                    """, {**clean, "now": now})
                return cur.lastrowid
            cur = self.conn.execute("""UPDATE tasks SET title=:title,description=:description,
                project=:project,tags=:tags,due=:due,status=:status,priority=:priority,
                estimate=:estimate,updated_at=:now WHERE id=:id""", {**clean, "now": now, "id": task_id})
            if cur.rowcount != 1:
                raise ValueError("任务已不存在，请刷新后重试")
        return task_id

    def move(self, task_id, status):
        task = self.get(task_id)
        if task is None:
            raise ValueError("任务不存在")
        task["status"] = status
        self.save(task, task_id)

    def delete(self, task_id):
        with self.conn:
            self.conn.execute("DELETE FROM tasks WHERE id=?", (task_id,))

    def clear_completed(self):
        with self.conn:
            return self.conn.execute("DELETE FROM tasks WHERE status='done'").rowcount

    def settings(self):
        return {**DEFAULTS, **{r["key"]: json.loads(r["value"])
                for r in self.conn.execute("SELECT * FROM settings")}}

    def save_settings(self, theme, priority, confirm_exit):
        if theme not in ("textual-dark", "textual-light", "nord") or priority not in PRIORITIES:
            raise ValueError("设置值无效")
        with self.conn:
            self.conn.executemany("INSERT OR REPLACE INTO settings(key,value) VALUES (?,?)",
                                 [(k, json.dumps(v)) for k, v in
                                  {"theme": theme, "default_priority": priority,
                                   "confirm_exit": bool(confirm_exit)}.items()])

    def backup(self):
        dest = self.path.with_name(f"taskflow-backup-{datetime.now():%Y%m%d-%H%M%S-%f}.db")
        with sqlite3.connect(dest) as target:
            self.conn.backup(target)
        return dest

    def seed(self):
        if self.list_tasks():
            raise ValueError("仅空数据库可以载入示例，避免与真实任务混合")
        examples = [
            ("梳理本周需求清单", "todo", "high", -1, "产品设计", "计划, 本周"),
            ("实现任务编辑表单", "doing", "high", 0, "TaskFlow", "Python, UI"),
            ("补充交互测试", "todo", "normal", 2, "TaskFlow", "测试"),
            ("检查数据备份", "doing", "normal", 3, "日常维护", "备份"),
            ("整理项目文档", "done", "low", -2, "TaskFlow", "文档"),
            ("规划下周学习内容", "todo", "low", 7, "个人成长", "学习"),
        ]
        for title, status, priority, offset, project, tags in examples:
            self.save(dict(title=title, status=status, priority=priority,
                           due=str(date.today() + timedelta(days=offset)), project=project,
                           tags=tags, estimate=2, description="这是示例任务，可以编辑或删除。"))
