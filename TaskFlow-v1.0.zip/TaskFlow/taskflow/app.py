"""TaskFlow UI. Run with python -m taskflow."""
from __future__ import annotations

import sqlite3
from datetime import date

from rich.text import Text
from textual import on
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.screen import ModalScreen
from textual.widgets import (Button, Checkbox, DataTable, Footer, Header, Input,
                             Label, ProgressBar, Select, Static, TabbedContent,
                             TabPane, TextArea)

from .storage import PRIORITIES, STATUSES, Store, ValidationError


class Confirm(ModalScreen[bool]):
    BINDINGS = [("escape", "cancel", "取消")]

    def __init__(self, title, message):
        super().__init__()
        self.heading, self.message = title, message

    def compose(self) -> ComposeResult:
        with Vertical(id="confirm-dialog"):
            yield Label(self.heading, classes="dialog-title")
            yield Static(self.message, markup=False, id="confirm-message")
            with Horizontal(classes="actions"):
                yield Button("取消", id="no")
                yield Button("确认", id="yes", variant="error")

    def on_mount(self):
        self.query_one("#no", Button).focus()

    @on(Button.Pressed)
    def answer(self, event):
        event.stop()
        self.dismiss(event.button.id == "yes")

    def action_cancel(self):
        self.dismiss(False)


class TaskForm(ModalScreen[bool]):
    BINDINGS = [("escape", "cancel", "取消")]

    def __init__(self, store: Store, task=None):
        super().__init__()
        self.store = store
        self.record = task or {}
        self.initial = None

    def compose(self) -> ComposeResult:
        t = self.record
        with Vertical(id="form-dialog"):
            yield Label("编辑任务" if t else "新建任务", classes="dialog-title")
            with VerticalScroll(id="form-body"):
                yield Label("标题 * · 1–100 字")
                yield Input(t.get("title", ""), placeholder="这项任务要完成什么？", id="f-title")
                yield Label("描述 · 最多 2000 字")
                yield TextArea(t.get("description", ""), id="f-description")
                with Horizontal(classes="field-row"):
                    with Vertical():
                        yield Label("状态 *")
                        yield Select([(v, k) for k, v in STATUSES.items()], value=t.get("status", "todo"), allow_blank=False, id="f-status")
                    with Vertical():
                        yield Label("优先级 *")
                        yield Select([(v, k) for k, v in PRIORITIES.items()], value=t.get("priority", self.store.settings()["default_priority"]), allow_blank=False, id="f-priority")
                with Horizontal(classes="field-row"):
                    with Vertical():
                        yield Label("截止日期 · 可留空")
                        yield Input(t.get("due", ""), placeholder="YYYY-MM-DD", id="f-due")
                    with Vertical():
                        yield Label("预计工时 · 0–10000")
                        yield Input(str(t.get("estimate", 0)), id="f-estimate")
                yield Label("项目 · 最多 40 字")
                yield Input(t.get("project", ""), id="f-project")
                yield Label("标签 · 逗号分隔，最多 8 个，每个 20 字")
                yield Input(t.get("tags", ""), placeholder="工作, 学习", id="f-tags")
            yield Static("* 为必填；过去的截止日期会显示为逾期。", id="form-errors", markup=False)
            with Horizontal(classes="actions"):
                yield Button("取消", id="cancel")
                yield Button("保存任务", id="save", variant="primary")

    def on_mount(self):
        self.initial = self.values()
        self.query_one("#f-title", Input).focus()

    def values(self):
        values = {key: self.query_one(f"#f-{key}", Input).value
                  for key in ("title", "due", "estimate", "project", "tags")}
        values["description"] = self.query_one("#f-description", TextArea).text
        for key in ("status", "priority"):
            values[key] = self.query_one(f"#f-{key}", Select).value
        return values

    @on(Button.Pressed, "#save")
    def save(self, event):
        event.stop()
        for widget in self.query(".invalid"):
            widget.remove_class("invalid")
        try:
            self.store.save(self.values(), self.record.get("id"))
        except ValidationError as error:
            self.query_one("#form-errors", Static).update("\n".join(error.errors.values()))
            for key in error.errors:
                self.query_one(f"#f-{key}").add_class("invalid")
            self.query_one(f"#f-{next(iter(error.errors))}").focus()
        except (sqlite3.Error, ValueError) as error:
            self.query_one("#form-errors", Static).update(f"保存失败：{error}")
        else:
            self.dismiss(True)

    @on(Button.Pressed, "#cancel")
    def cancel_clicked(self, event):
        event.stop()
        self.action_cancel()

    def action_cancel(self):
        if self.values() != self.initial:
            self.app.push_screen(Confirm("放弃修改？", "表单中存在未保存的内容。确认后将丢弃这些修改。"), self.discard)
        else:
            self.dismiss(False)

    def discard(self, confirmed):
        if confirmed:
            self.dismiss(False)


class TaskCard(Vertical):
    def __init__(self, task):
        super().__init__(classes="task-card")
        self.record = task

    def compose(self):
        t = self.record
        due = t["due"] or "无截止日期"
        overdue = bool(t["due"] and t["due"] < str(date.today()) and t["status"] != "done")
        yield Static(f"#{t['id']}  {t['title']}", markup=False, classes="card-title")
        yield Static(f"{PRIORITIES[t['priority']]}优先级 · {t['project'] or '未分项目'}", markup=False)
        yield Static(("逾期 · " if overdue else "") + due, classes="overdue" if overdue else "muted")
        if t["tags"]:
            yield Static(t["tags"], markup=False, classes="muted")
        with Horizontal(classes="card-actions"):
            yield Button("编辑", id=f"card-edit-{t['id']}")
            yield Button("下一步 →" if t["status"] != "done" else "重新打开", id=f"card-move-{t['id']}", variant="primary")


class TaskFlow(App):
    TITLE = "TaskFlow"
    SUB_TITLE = "专注当下，让任务有序推进"
    CSS_PATH = "styles.tcss"
    BINDINGS = [
        ("ctrl+n", "new_task", "新建任务"),
        Binding("f1", "page('dashboard')", "仪表盘", priority=True),
        Binding("f2", "page('tasks')", "任务", priority=True),
        Binding("f3", "page('board')", "看板", priority=True),
        Binding("f4", "page('settings')", "设置", priority=True),
        ("ctrl+r", "refresh", "刷新"),
        ("ctrl+q", "request_quit", "退出"),
    ]

    def __init__(self, store: Store):
        super().__init__()
        self.store = store
        self.selected_id = None
        self.ready = False
        self.theme = store.settings()["theme"]

    def compose(self) -> ComposeResult:
        settings = self.store.settings()
        yield Header(show_clock=True)
        with TabbedContent(initial="dashboard", id="pages"):
            with TabPane("仪表盘", id="dashboard"):
                with VerticalScroll():
                    yield Static("工作概览", classes="page-title")
                    yield Static("每一个小小的完成，都在推动计划前进。", classes="muted")
                    with Horizontal(id="stats"):
                        for key in ("total", "doing", "done", "overdue"):
                            yield Static("", id=f"stat-{key}", classes="stat")
                    yield Label("任务完成率", classes="section-title")
                    yield ProgressBar(total=100, show_eta=False, id="completion")
                    yield Static("", id="completion-text")
                    with Horizontal(classes="actions"):
                        yield Button("新建任务", id="dash-new", variant="primary")
                        yield Button("查看全部", id="dash-all")
                    yield Label("待关注 · 按截止日期排列，最多 8 项", classes="section-title")
                    yield DataTable(id="upcoming", cursor_type="row", zebra_stripes=True)
                    yield Static("", id="dash-empty", classes="muted")
            with TabPane("任务列表", id="tasks"):
                yield Static("所有任务", classes="page-title")
                with Horizontal(id="filters"):
                    yield Input(placeholder="搜索标题 / 描述 / 项目 / 标签", id="search")
                    yield Select([("全部状态", "all")] + [(v, k) for k, v in STATUSES.items()], value="all", allow_blank=False, id="filter-status")
                    yield Select([("全部优先级", "all")] + [(v, k) for k, v in PRIORITIES.items()], value="all", allow_blank=False, id="filter-priority")
                    yield Select([("按截止日期", "due"), ("按优先级", "priority"), ("最新创建", "newest")], value="due", allow_blank=False, id="sort")
                with Horizontal(classes="actions"):
                    yield Button("新建", id="new", variant="primary")
                    yield Button("编辑", id="edit", disabled=True)
                    yield Button("推进状态", id="move", disabled=True)
                    yield Button("删除", id="delete", variant="error", disabled=True)
                    yield Button("重置筛选", id="reset-filters")
                yield DataTable(id="task-table", cursor_type="row", zebra_stripes=True)
                yield Static("", id="list-summary", markup=False)
                yield Static("选择一行后可编辑；Enter 或双击打开表单。", id="selected-detail", markup=False)
            with TabPane("看板", id="board"):
                yield Static("推进你的工作", classes="page-title")
                yield Static("看板显示全部任务。点击卡片的「下一步」推进状态；已完成任务可以重新打开。", classes="muted")
                with Horizontal(id="board-columns"):
                    for key, title in STATUSES.items():
                        with Vertical(classes="board-column"):
                            yield Label(title, id=f"heading-{key}", classes="column-title")
                            yield VerticalScroll(id=f"column-{key}")
            with TabPane("设置", id="settings"):
                with VerticalScroll(id="settings-body"):
                    yield Static("偏好与数据", classes="page-title")
                    yield Label("界面主题")
                    yield Select([("深色", "textual-dark"), ("浅色", "textual-light"), ("Nord", "nord")], value=settings["theme"], allow_blank=False, id="theme-select")
                    yield Label("新建任务默认优先级")
                    yield Select([(v, k) for k, v in PRIORITIES.items()], value=settings["default_priority"], allow_blank=False, id="default-priority")
                    yield Checkbox("退出前确认", value=settings["confirm_exit"], id="confirm-exit")
                    yield Button("保存设置", id="save-settings", variant="primary")
                    yield Label("本地 SQLite 数据库", classes="section-title")
                    yield Static(str(self.store.path), markup=False, id="db-path")
                    yield Static("任务保存后立即写入数据库；备份包含任务和设置。恢复备份请先退出应用。", classes="muted")
                    with Horizontal(classes="actions"):
                        yield Button("创建备份", id="backup")
                        yield Button("载入示例", id="seed")
                        yield Button("清理已完成", id="clear-done", variant="error")
                    yield Static("示例仅可在空数据库中载入。", id="settings-message", markup=False)
        yield Footer()

    async def on_mount(self):
        self.query_one("#task-table", DataTable).add_columns("ID", "任务", "状态", "优先级", "截止日期", "项目", "工时")
        self.query_one("#upcoming", DataTable).add_columns("ID", "任务", "状态", "截止日期")
        self.ready = True
        await self.refresh_data()
        self.set_interval(60, self.refresh_data)

    def home_visible(self):
        return not isinstance(self.screen, ModalScreen)

    def action_page(self, name):
        if self.home_visible():
            pages = self.query_one("#pages", TabbedContent)
            self.set_focus(None)
            pages.active = name
            pages.get_tab(name).focus()

    def action_new_task(self):
        if self.home_visible():
            self.push_screen(TaskForm(self.store), self.after_form)

    async def after_form(self, saved):
        if saved:
            await self.refresh_data()
            self.notify("任务已保存")

    async def action_refresh(self):
        if self.home_visible():
            await self.refresh_data()

    def action_request_quit(self):
        if not self.home_visible():
            return
        if self.store.settings()["confirm_exit"]:
            self.push_screen(Confirm("退出 TaskFlow？", "已保存的任务已写入本地数据库。"), lambda ok: self.exit() if ok else None)
        else:
            self.exit()

    async def refresh_data(self):
        if not self.ready or not self.home_visible():
            return
        rows = self.store.list_tasks()
        today = str(date.today())
        done = sum(r["status"] == "done" for r in rows)
        overdue = sum(bool(r["due"] and r["due"] < today and r["status"] != "done") for r in rows)
        values = {"total": ("全部任务", len(rows)), "doing": ("进行中", sum(r["status"] == "doing" for r in rows)),
                  "done": ("已完成", done), "overdue": ("已逾期", overdue)}
        for key, (label, value) in values.items():
            self.query_one(f"#stat-{key}", Static).update(f"{label}\n{value}")
        percent = done / len(rows) * 100 if rows else 0
        self.query_one("#completion", ProgressBar).update(progress=percent)
        self.query_one("#completion-text", Static).update(f"{done} / {len(rows)} 已完成 · {percent:.0f}%")
        upcoming = self.query_one("#upcoming", DataTable)
        upcoming.clear()
        pending = [r for r in rows if r["status"] != "done"][:8]
        for r in pending:
            upcoming.add_row(str(r["id"]), Text(r["title"]), STATUSES[r["status"]], r["due"] or "—", key=str(r["id"]))
        self.query_one("#dash-empty", Static).update("暂无待办任务。新建任务或到设置页载入示例。" if not pending else "选中任务并按 Enter 可编辑。")
        self.refresh_table()
        for status in STATUSES:
            column = self.query_one(f"#column-{status}", VerticalScroll)
            await column.remove_children()
            tasks = [r for r in rows if r["status"] == status]
            self.query_one(f"#heading-{status}", Label).update(f"{STATUSES[status]} · {len(tasks)}")
            await column.mount(*(TaskCard(t) for t in tasks)) if tasks else await column.mount(Static("暂无任务", classes="empty"))

    def refresh_table(self):
        table = self.query_one("#task-table", DataTable)
        selected = self.selected_id
        rows = self.store.list_tasks(self.query_one("#search", Input).value,
                                    self.query_one("#filter-status", Select).value,
                                    self.query_one("#filter-priority", Select).value,
                                    self.query_one("#sort", Select).value)
        table.clear()
        for r in rows:
            due = r["due"] or "—"
            if r["due"] and r["due"] < str(date.today()) and r["status"] != "done":
                due = Text(due + " !", style="bold red")
            table.add_row(str(r["id"]), Text(r["title"]), STATUSES[r["status"]], PRIORITIES[r["priority"]], due,
                          Text(r["project"] or "—"), f"{r['estimate']:g}", key=str(r["id"]))
        index = next((i for i, r in enumerate(rows) if r["id"] == selected), 0)
        if rows:
            table.move_cursor(row=index)
        self.set_selected(rows[index]["id"] if rows else None)
        self.query_one("#list-summary", Static).update(f"当前显示 {len(rows)} 项任务" + (" · 没有匹配结果，请新建任务或调整筛选。" if not rows else ""))

    def set_selected(self, task_id):
        self.selected_id = task_id
        for key in ("edit", "move", "delete"):
            self.query_one(f"#{key}", Button).disabled = task_id is None
        task = self.store.get(task_id) if task_id is not None else None
        self.query_one("#selected-detail", Static).update(
            f"#{task_id} · {task['title']}\n标签：{task['tags'] or '无'} · {task['description'][:160]}" if task else "选择任务后可编辑、推进状态或删除。")

    @on(DataTable.RowHighlighted, "#task-table")
    def highlighted(self, event):
        if event.row_key.value is not None:
            self.set_selected(int(event.row_key.value))

    @on(DataTable.RowSelected)
    def open_row(self, event):
        self.edit_task(int(event.row_key.value))

    def edit_task(self, task_id):
        task = self.store.get(task_id)
        if task:
            self.push_screen(TaskForm(self.store, task), self.after_form)

    @on(Input.Changed, "#search")
    def search_changed(self):
        if self.ready:
            self.refresh_table()

    @on(Select.Changed)
    def filter_changed(self, event):
        if self.ready and event.select.id in ("filter-status", "filter-priority", "sort"):
            self.refresh_table()

    async def advance(self, task_id):
        task = self.store.get(task_id)
        if task:
            status = {"todo": "doing", "doing": "done", "done": "todo"}[task["status"]]
            self.store.move(task_id, status)
            await self.refresh_data()
            self.notify(f"任务已移至：{STATUSES[status]}")

    @on(Button.Pressed)
    async def button_clicked(self, event):
        name = event.button.id or ""
        try:
            if name in ("new", "dash-new"):
                self.action_new_task()
            elif name == "dash-all":
                self.action_page("tasks")
            elif name == "edit" and self.selected_id:
                self.edit_task(self.selected_id)
            elif name == "move" and self.selected_id:
                await self.advance(self.selected_id)
            elif name.startswith("card-edit-"):
                self.edit_task(int(name.rsplit("-", 1)[1]))
            elif name.startswith("card-move-"):
                await self.advance(int(name.rsplit("-", 1)[1]))
            elif name == "delete" and self.selected_id:
                task_id = self.selected_id
                task = self.store.get(task_id)
                if task:
                    async def remove(ok):
                        if ok:
                            try:
                                self.store.delete(task_id)
                                await self.refresh_data()
                            except sqlite3.Error as error:
                                self.notify(str(error), severity="error")
                    self.push_screen(Confirm("删除任务？", f"即将永久删除 #{task_id}「{task['title']}」。此操作不可撤销。"), remove)
            elif name == "reset-filters":
                self.query_one("#search", Input).value = ""
                for key in ("filter-status", "filter-priority"):
                    self.query_one(f"#{key}", Select).value = "all"
                self.query_one("#sort", Select).value = "due"
                self.refresh_table()
            elif name == "save-settings":
                theme = self.query_one("#theme-select", Select).value
                self.store.save_settings(theme, self.query_one("#default-priority", Select).value,
                                         self.query_one("#confirm-exit", Checkbox).value)
                self.theme = theme
                self.query_one("#settings-message", Static).update("设置已保存，下次启动自动恢复。")
                self.notify("设置已保存")
            elif name == "backup":
                path = self.store.backup()
                self.query_one("#settings-message", Static).update(f"备份已创建：{path}")
                self.notify("备份成功")
            elif name == "seed":
                if self.store.list_tasks():
                    self.notify("仅空数据库可载入示例", severity="warning")
                else:
                    self.push_screen(Confirm("载入示例？", "将新增 6 条示例任务，方便体验所有页面。"), self.seed_confirmed)
            elif name == "clear-done":
                self.push_screen(Confirm("清理全部已完成任务？", "此操作将永久删除已完成任务。建议先创建备份。"), self.clear_confirmed)
        except (sqlite3.Error, OSError, ValueError) as error:
            self.notify(f"操作失败：{error}", severity="error", timeout=8)

    async def seed_confirmed(self, ok):
        if ok:
            try:
                self.store.seed()
                await self.refresh_data()
                self.notify("已载入 6 条示例任务")
            except (sqlite3.Error, ValueError) as error:
                self.notify(str(error), severity="error")

    async def clear_confirmed(self, ok):
        if ok:
            try:
                count = self.store.clear_completed()
                await self.refresh_data()
                self.notify(f"已清理 {count} 条已完成任务")
            except sqlite3.Error as error:
                self.notify(str(error), severity="error")
