@echo off
setlocal
cd /d "%~dp0"
if exist .venv\Scripts\python.exe goto run
where py >nul 2>nul
if errorlevel 1 goto usepython
py -3 -m venv .venv
goto checkvenv
:usepython
python -m venv .venv
:checkvenv
if not exist .venv\Scripts\python.exe goto failed
:run
.venv\Scripts\python.exe -c "import textual; assert textual.__version__ == '8.2.8'" >nul 2>nul
if not errorlevel 1 goto launch
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto failed
:launch
.venv\Scripts\python.exe -m taskflow %*
if errorlevel 1 goto failed
exit /b 0
:failed
echo TaskFlow could not start. Install Python 3.10+ and check the errors above.
pause
exit /b 1
