import pytest
from textual.widgets import Input, Select, TabbedContent, DataTable, Checkbox
from taskflow.app import TaskFlow, TaskForm, Confirm, TaskCard
from taskflow.storage import Store


@pytest.mark.asyncio
async def test_full_task_flow(tmp_path):
    store = Store(tmp_path / "ui.db")
    app = TaskFlow(store)
    async with app.run_test(size=(120, 45)) as pilot:
        await pilot.pause(0.35)
        assert app.query_one("#task-table", DataTable).row_count == 0
        await pilot.press("ctrl+n")
        await pilot.pause(0.35)
        assert isinstance(app.screen, TaskForm)
        await pilot.click("#save")
        await pilot.pause(0.35)
        assert isinstance(app.screen, TaskForm)
        assert app.screen.query_one("#f-title").has_class("invalid")
        app.screen.query_one("#f-title", Input).value = "测试新任务"
        app.screen.query_one("#f-due", Input).value = "2026-02-30"
        await pilot.click("#save")
        await pilot.pause(0.35)
        assert app.screen.query_one("#f-due").has_class("invalid")
        app.screen.query_one("#f-due", Input).value = "2026-12-31"
        await pilot.click("#save")
        await pilot.pause(0.35)
        tid = store.list_tasks()[0]["id"]
        assert app.query_one("#task-table", DataTable).row_count == 1
        await pilot.press("f2")
        await pilot.pause(0.35)
        assert app.query_one("#pages", TabbedContent).active == "tasks"
        await pilot.click("#edit")
        await pilot.pause(0.35)
        app.screen.query_one("#f-title", Input).value = "已编辑任务"
        await pilot.click("#save")
        await pilot.pause(0.35)
        assert store.get(tid)["title"] == "已编辑任务"
        app.query_one("#search", Input).value = "无匹配"
        await pilot.pause(0.35)
        assert app.query_one("#task-table", DataTable).row_count == 0
        await pilot.click("#reset-filters")
        await pilot.pause(0.35)
        assert app.query_one("#task-table", DataTable).row_count == 1
        await pilot.press("f3")
        await pilot.pause(0.35)
        assert app.query_one("#pages", TabbedContent).active == "board"
        assert await pilot.click(f"#card-move-{tid}")
        await pilot.pause(0.35)
        assert store.get(tid)["status"] == "doing"
        assert len(app.query_one("#column-doing").query(TaskCard)) == 1
        assert app.query_one("#pages", TabbedContent).active == "board"
        assert await pilot.click(f"#card-move-{tid}")
        await pilot.pause(0.35)
        assert store.get(tid)["status"] == "done"
        await pilot.press("f2")
        await pilot.pause(0.35)
        await pilot.click("#delete")
        await pilot.pause(0.35)
        assert isinstance(app.screen, Confirm)
        await pilot.click("#no")
        await pilot.pause(0.35)
        assert store.get(tid)
        await pilot.click("#delete")
        await pilot.pause(0.35)
        await pilot.click("#yes")
        await pilot.pause(0.35)
        assert store.get(tid) is None
        await pilot.press("f4")
        await pilot.pause(0.35)
        app.query_one("#theme-select", Select).value = "nord"
        app.query_one("#default-priority", Select).value = "high"
        app.query_one("#confirm-exit", Checkbox).value = False
        await pilot.click("#save-settings")
        await pilot.pause(0.35)
        assert app.theme == "nord"
        await pilot.click("#backup")
        await pilot.pause(0.35)
        assert list(tmp_path.glob("taskflow-backup-*.db"))
    store.close()
    store = Store(tmp_path / "ui.db")
    assert store.settings()["default_priority"] == "high"
    assert store.settings()["confirm_exit"] is False
    store.close()


@pytest.mark.asyncio
async def test_discard_demo_resize_and_exit(tmp_path):
    store = Store(tmp_path / "ui.db")
    app = TaskFlow(store)
    async with app.run_test(size=(100, 32)) as pilot:
        await pilot.press("f4")
        await pilot.pause(0.35)
        app.query_one("#seed").scroll_visible()
        await pilot.pause(0.35)
        await pilot.click("#seed")
        await pilot.pause(0.35)
        await pilot.click("#yes")
        await pilot.pause(0.35)
        assert len(store.list_tasks()) == 6
        await pilot.press("ctrl+n")
        await pilot.pause(0.35)
        app.screen.query_one("#f-title", Input).value = "不保存"
        await pilot.press("escape")
        await pilot.pause(0.35)
        assert isinstance(app.screen, Confirm)
        await pilot.click("#no")
        await pilot.pause(0.35)
        assert isinstance(app.screen, TaskForm)
        await pilot.press("escape")
        await pilot.pause(0.35)
        await pilot.click("#yes")
        await pilot.pause(0.35)
        assert len(store.list_tasks()) == 6
        for size in ((80, 24), (160, 48)):
            await pilot.resize_terminal(*size)
            for page in ("f1", "f2", "f3", "f4"):
                await pilot.press(page)
                await pilot.pause(0.35)
        app.query_one("#clear-done").scroll_visible()
        await pilot.pause(0.35)
        await pilot.click("#clear-done")
        await pilot.pause(0.35)
        await pilot.click("#yes")
        await pilot.pause(0.35)
        assert len(store.list_tasks()) == 5
        await pilot.press("ctrl+q")
        await pilot.pause(0.35)
        assert isinstance(app.screen, Confirm)
        await pilot.click("#no")
        await pilot.pause(0.35)
    store.close()
