import pytest
from taskflow.storage import Store, ValidationError, validate_task


def task(**changes):
    return dict(title="测试任务", description="说明", status="todo", priority="normal",
                due="", project="测试", tags="Python，测试, Python", estimate=1.5, **changes)


@pytest.mark.parametrize("field,value", [
    ("title", "  "), ("title", "x" * 101), ("description", "x" * 2001),
    ("project", "x" * 41), ("tags", "x" * 21), ("tags", ",".join(str(i) for i in range(9))),
    ("due", "2026-02-30"), ("due", "2026-1-1"), ("status", "bad"),
    ("priority", "bad"), ("estimate", "nan"), ("estimate", "inf"),
    ("estimate", "-1"), ("estimate", "10001"), ("estimate", "abc"),
])
def test_invalid(field, value):
    data = task()
    data[field] = value
    with pytest.raises(ValidationError) as error:
        validate_task(data)
    assert field in error.value.errors


def test_persistence_search_backup(tmp_path):
    db = tmp_path / "tasks.db"
    store = Store(db)
    data = task()
    data["title"] = "[red]用户输入[/red] ' SQL"
    tid = store.save(data)
    assert store.get(tid)["tags"] == "Python, 测试"
    store.move(tid, "doing")
    assert len(store.list_tasks(search="PYTHON", status="doing")) == 1
    assert not store.list_tasks(search="%")
    store.save_settings("nord", "high", False)
    backup = store.backup()
    store.close()
    store = Store(db)
    assert store.get(tid)["status"] == "doing"
    assert store.settings()["theme"] == "nord"
    store.delete(tid)
    assert not store.list_tasks()
    store.close()
    copy = Store(backup)
    assert copy.get(tid)["title"] == data["title"]
    copy.close()


def test_seed_and_cleanup(tmp_path):
    store = Store(tmp_path / "test.db")
    store.seed()
    assert len(store.list_tasks()) == 6
    with pytest.raises(ValueError):
        store.seed()
    assert store.clear_completed() == 1
    assert len(store.list_tasks()) == 5
    store.close()
