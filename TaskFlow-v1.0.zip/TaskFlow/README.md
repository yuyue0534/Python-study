# TaskFlow · 全屏终端任务管理器

Python + Textual + SQLite。中文界面、本地存储，无需账号、服务器或 API Key。

## 快速启动

需要 Python 3.10+。本项目实际验证环境为 Linux / Python 3.12.14 / Textual 8.2.8。
Windows 建议在 Windows Terminal 中运行，窗口建议至少 100 列 × 32 行。

### Windows

解压后双击 `start.bat`。首次启动会创建虚拟环境并联网安装依赖，以后直接启动。
也可以在解压目录打开 PowerShell，执行：

```powershell
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m taskflow
```

体验示例（仅空数据库自动加入 6 条示例，不覆盖现有任务）：

```powershell
.\.venv\Scripts\python.exe -m taskflow --db .\demo.db --demo
```

### Linux / macOS

```bash
bash start.sh
# 或：
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m taskflow --db ./demo.db --demo
```

依赖安装完毕后可离线运行。不要在不支持完整终端控制的 IDE Output 窗格中运行，
应使用 Terminal 终端。若提示找不到 Python，需要先安装 Python 并配置 PATH。

## 已实现功能

| 页面 | 功能 |
| --- | --- |
| 仪表盘 | 全部/进行中/完成/逾期统计、完成率进度条、待关注任务、新建入口 |
| 任务列表 | 新建、编辑、删除确认、推进状态、搜索、状态/优先级筛选、截止日期/优先级/创建时间排序 |
| 看板 | 待办/进行中/已完成三列、独立滚动、卡片信息、编辑、状态推进、重新打开 |
| 设置 | 深色/浅色/Nord 主题、默认优先级、退出确认、SQLite 备份、示例任务、清理已完成 |

任务字段包括标题、描述、状态、优先级、截止日期、预计工时、项目和标签。
任务列表搜索覆盖标题、描述、项目、标签；看板和仪表盘始终展示全量数据，不受列表筛选影响。
表单有错误提示、红色字段边框、首个错误字段定位；未保存关闭需再次确认。
所有任务改动立即提交到 SQLite；设置需要点击“保存设置”才会持久化和切换主题。

## 操作

| 按键/操作 | 功能 |
| --- | --- |
| F1 / F2 / F3 / F4 | 仪表盘 / 任务列表 / 看板 / 设置 |
| Ctrl+N | 新建任务 |
| Ctrl+R | 刷新数据 |
| Ctrl+Q | 退出（默认确认） |
| Tab / Shift+Tab | 切换焦点 |
| 方向键 | 表格行、选项或文本光标移动 |
| Enter | 表格打开任务；按钮触发；下拉框选择 |
| Esc | 关闭表单或取消确认（表单有修改时先确认） |
| 鼠标 | 切换页签、点击按钮、滚轮滚动 |

看板按按钮推进 `待办 → 进行中 → 已完成 → 待办`，也可在编辑表单中直接选择状态。
本版本不提供拖拽卡片。窄窗口可滚动看板；表单底部保存/取消按钮固定可见，中间字段可滚动。
多行描述框会捕获部分编辑快捷键，请用鼠标或 Tab 切换到其他控件。

## 校验规则

- 标题必填，去除首尾空白后为 1–100 字。
- 描述最多 2000 字，项目最多 40 字。
- 日期可留空；填写时必须为真实有效的 `YYYY-MM-DD`。允许过去日期，未完成时标记逾期。
- 工时可留空（按 0 处理），必须为 0–10000 的有限数字；拒绝 NaN、Infinity、负数。
- 标签以中英文逗号分隔，去重；最多 8 个，每个最多 20 字，原始输入最多 200 字。
- 状态、优先级必须为预定义选项；数据库也约束这些枚举与工时范围。
- 完成率 = 已完成任务数 / 全部任务数，空数据库显示 0%。逾期判定使用运行电脑的本地日期。

## 数据与备份

默认位置：`~/.taskflow/taskflow.db`。Windows 通常为 `C:\Users\你的用户名\.taskflow\taskflow.db`。
可通过 `--db 路径` 或 `TASKFLOW_DB` 环境变量指定其他数据库；设置页显示实际绝对路径。
同一用户从不同工作目录启动时会打开同一个默认数据库。

“创建备份”使用 SQLite Backup API，备份保存在数据库同目录，包含任务与设置。
**恢复最简单的方式**：退出 TaskFlow，使用 `python -m taskflow --db "备份文件路径"` 启动。
若要替换默认数据库，必须先关闭所有使用该库的进程，再保留原文件并处理同名 WAL/SHM 文件；
直接以备份路径启动更简单。运行期间不要只复制 `.db` 文件，因为可能还有尚未归并的 WAL 数据。
删除与清理不可撤销，确认前建议备份。

## 源码结构

- `taskflow/__main__.py`：命令行入口、路径选择、初始化、资源关闭。
- `taskflow/storage.py`：SQLite、业务校验、查询、备份、设置和示例。
- `taskflow/app.py`：四个页签页面、任务表单、确认模态、看板卡片、事件处理。
- `taskflow/styles.tcss`：界面布局与主题变量样式。
- `tests/test_storage.py`：校验边界、数据库重开、备份和筛选。
- `tests/test_ui.py`：Textual Pilot 控件交互测试。
- `TEST_REPORT.md`：实际验证记录及限制。

## 运行测试

```bash
python -m pip install -r requirements-dev.txt
python -m pytest -q
```

测试使用临时数据库，不读写真实任务。Textual Pilot 会启动真实应用事件循环，
模拟按键、点击、页面切换及窗口缩放；不是对业务方法的简单 mock。

## 范围与限制

这是面向个人、适中任务量的本地应用；没有账号权限、云同步、定时通知、拖拽或并发冲突合并。
看板会构建全部卡片，大规模任务库需进一步做分页/虚拟化；备份与小型数据库操作同步执行。
Windows 启动脚本已提供，但交付环境为 Linux，未声称在 Windows 实机测试。

参考：Textual 官方 https://textual.textualize.io/ ，SQLite 标准库 https://docs.python.org/3/library/sqlite3.html 。
